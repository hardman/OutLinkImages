//
//  TestDownloadFramework.h
//  TestDownloadFramework
//
//  Created by hongyuwang on 2019/2/1.
//  Copyright © 2019 hongyuwang. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TestDownloadFramework.
FOUNDATION_EXPORT double TestDownloadFrameworkVersionNumber;

//! Project version string for TestDownloadFramework.
FOUNDATION_EXPORT const unsigned char TestDownloadFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestDownloadFramework/PublicHeader.h>


